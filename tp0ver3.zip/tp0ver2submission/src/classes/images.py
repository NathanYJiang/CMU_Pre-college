class Image:
    pass