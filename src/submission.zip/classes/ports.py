class Ports:
    def __init__(self):
        self.ports = {
            (3, 2.5): None, 
            (7, 2.5): None, 
            (10, 1.5): None, 
            (12, -0.5): None, 
            (10, -2.5): None, 
            (7, -3.5): None, 
            (3, -3.5): None, 
            (1, -1.5): None, 
            (1, 0.5): None
        }