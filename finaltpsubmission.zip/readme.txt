My term project is Settlers of Ketan, a reimplementation of
the board game Settlers of Catan.

Run main.py.

No libraries need to be installed.

Press r to get free resources (one of each).